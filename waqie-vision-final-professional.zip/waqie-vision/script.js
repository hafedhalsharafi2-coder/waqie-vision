document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.getElementById("contactForm");

    if (contactForm) {
        contactForm.addEventListener("submit", function(event) {
            event.preventDefault();

            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const subject = document.getElementById("subject").value.trim();
            const message = document.getElementById("message").value.trim();

            if (name === "" || email === "" || subject === "" || message === "") {
                alert("الرجاء تعبئة جميع الحقول قبل إرسال الرسالة.");
                return;
            }

            alert(`شكرًا لك يا ${name}.\nتم استلام رسالتك حول: ${subject}\nسيطلع عليها فريق صحيفة واقع الرؤية.`);
            contactForm.reset();
        });
    }
});
